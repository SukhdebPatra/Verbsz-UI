import "./Home.css";
import {
  Mail,
  MapPin,
  Phone,
  Target,
  TrendingUp,
  SlidersHorizontal,
  DollarSign,
  ArrowRight,
} from "lucide-react";

const Home = () => {
  return (
    <>
      <div className="">
        <section className="">
          {/* Navigation Bar */}
          <nav className="p-8 flex items-center justify-between  ">
            {/* Logo */}
            <div className="text-3xl font-bold text-[#3cb4e5]">Logo</div>

            {/* Navigation Links (hidden on mobile, shown on desktop) */}
            <div className="hidden md:flex items-center space-x-8">
              <a
                href="#"
                className="text-gray-600 hover:text-blue-700 transition-colors duration-200"
              >
                Services
              </a>
              <a
                href="#"
                className="text-gray-600 hover:text-blue-700 transition-colors duration-200"
              >
                Projects
              </a>
              <a
                href="#"
                className="text-gray-600 hover:text-blue-700 transition-colors duration-200"
              >
                Insights
              </a>
              <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-md transition-all duration-300">
                Put Us To Work
              </button>
            </div>

            {/* Mobile Menu Icon (Hamburger) - for future implementation */}
            <div className="md:hidden">
              {/* You can add a hamburger icon here and implement mobile menu toggle */}
              <button className="text-gray-600 focus:outline-none"></button>
            </div>
          </nav>

          {/* Main Content Section */}
        </section>
      </div>

      <section className="ml-20">
        <div className="flex  flex-col md:flex-row items-center justify-center p-8 md:p-12 lg:p-20">
          {/* Left Section: Text Content */}
          <div className="md:w-1/2 lg:w-2/5 mb-10 md:mb-0 md:pr-10 text-center md:text-left">
            <h1 className="text-4xl lg:text-5xl font-extrabold text-[#0B325F] leading-tight mb-6">
              Market <br className="hidden md:block" /> Validation
            </h1>

            <p className="text-gray-700 text-lg mb-8 leading-relaxed">
              Market Validation is the process of presenting a concept for a
              product to its target market and learning from those prospective
              buyers whether or not the idea is worth pursuing.
            </p>
            <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-all duration-300">
              Put Us To Work
            </button>
          </div>

          {/* Right Section: Image and Cards */}
          <div className="md:w-1/2 lg:w-3/5 relative flex justify-center items-center">
            {/* Main Image */}
            <div className="relative z-10 w-full max-w-lg rounded-3xl overflow-hidden ">
              <img
                src="src/assets/imges/1.png"
                alt="Business meeting"
                className="w-full h-auto object-cover"
              />
            </div>

            {/* Overlaid Card 1: Generate Traffic */}
            <div className="absolute  left-1/4 md:left-10 lg:left-20 bg-white p-6 rounded-2xl shadow-xl transform -translate-x-1/2 -translate-y-1/2 md:translate-x-0 md:-translate-y-1/4 lg:-translate-y-1/2 z-20 transition-all duration-300 hover:scale-105 border border-gray-100 w-25 h-25 flex flex-col justify-center items-center top-[50%]">
              <div className="bg-blue-100 p-4 rounded-full mb-3">
                {/* Image Icon for Generate Traffic */}
                <img
                  src="src/assets/imges/Image 2.png" // Updated icon source
                  alt="Generate Traffic Icon"
                  className="w-8 h-8 object-contain relative"
                />
              </div>
              <p className="text-gray-800 text-center text-sm font-semibold">
                Generate Traffic
              </p>
            </div>

            {/* Overlaid Card 2: Launch Sales */}
            <div className="absolute  right-1/4 md:right-10 lg:right-20 bg-white p-6 rounded-2xl shadow-xl transform translate-x-1/2 translate-y-1/2 md:translate-x-0 md:translate-y-1/4 lg:translate-y-1/2 z-20 transition-all duration-300 hover:scale-105 border border-gray-100 w-25 h-25 flex flex-col justify-center items-center ">
              <div className="bg-blue-100 p-4 rounded-full mb-3">
                {/* Image Icon for Launch Sales */}
                <img
                  src="src/assets/imges/start-up.png" // Updated icon source
                  alt="Launch Sales Icon"
                  className="w-8 h-8 object-contain"
                />
              </div>
              <p className="text-gray-800 text-center text-sm font-semibold">
                Launch Sales
              </p>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="flex items-center w-full mt-5">
          {/* Left line – 20% width */}
          <hr className="w-[10%] border-t border-gray-300" />

          {/* Email in the center */}
          <span className="text-blue-500 hover:text-blue-700 text-2xl mx-4 whitespace-nowrap">
            hello@domain.com
          </span>

          {/* Right line – takes remaining 80% minus spacing */}
          <hr className="flex-grow border-t border-gray-300" />
        </div>
      </section>

      <section>
        <div className="min-h-screen  font-sans flex flex-col items-center p-4">
          {/* Main content card */}
          <div>
            <div className="bg-white  p-6 sm:p-8 md:p-12 lg:p-16 max-w-6xl w-full my-4 sm:my-8 transform transition-all duration-300">
              {/* Top section: Title, Description, and Call-to-action button */}

              <div className="flex flex-row justify-between items-center mb-8 md:mb-12 gap-4 flex-wrap">
                <div className="w-full md:w-2/3 pr-0 md:pr-8">
                  <h1 className="text-4xl sm:text-5xl lg:text-3xl font-bold text-gray-900 leading-tight mb-2">
                    We Can <br className="hidden sm:inline" /> Help With
                  </h1>
                  <p className="text-gray-600 text-base sm:text-lg">
                    Before sinking tons of money into product development, find
                    out what matters most to your audience. Learn the ins and
                    outs of their preferences and cater your product to meet
                    those needs.
                  </p>
                </div>
                <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 whitespace-nowrap">
                  Put Us To Work
                </button>
              </div>

              {/* Feature Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Highlighted Card: Identifying Target Audiences */}
                <div className="bg-blue-900 text-white rounded-2xl p-6 flex flex-col justify-between shadow-xl transform transition-transform duration-300 hover:scale-105">
                  <div className="mb-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-full inline-flex mb-4">
                      <img src="src/assets/imges/Group 32.svg" alt="" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">
                      Identifying Target Audiences
                    </h3>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      Simply dummy text of the printing and typesetting
                      industry. Lorem ipsum has been the industry's standard
                      dummy text ever since the 1500s, when an unknown printer
                      took.
                    </p>
                  </div>
                  <div className="self-end mt-4">
                    <button className="p-3 bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                      <ArrowRight size={24} />
                    </button>
                  </div>
                </div>

                {/* Other Cards */}
                {/* Card: Generating Conversions */}

                <div
                  className="
   text-black bg-gray-100 hover:bg-blue-900 hover:text-white rounded-2xl p-6 flex flex-col justify-between shadow-xl
  transform transition-transform duration-300 hover:scale-105
  relative group  // Add 'group' class here
"
                >
                  <div className="mb-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-full inline-flex mb-4">
                      <img src="src/assets/imges/Group 15.svg" alt="" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">
                      Generating Conversions
                    </h3>
                    {/* This paragraph will show on hover */}
                    <p
                      className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
      transition-opacity duration-300     // Smooth transition for opacity
    "
                    >
                      Simply dummy text of the printing and typesetting
                      industry. Lorem ipsum has been the industry's standard
                      dummy text ever since the 1500s, when an unknown printer
                      took.
                    </p>
                  </div>
                  {/* This div containing the button will also show on hover */}
                  <div
                    className="
    self-end mt-4
    opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
    transition-opacity duration-300     // Smooth transition for opacity
  "
                  >
                    <button className="p-3 bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                      <ArrowRight size={24} />
                    </button>
                  </div>
                </div>

                {/* Card: Optimizing Product Features */}
                <div
                  className="
   text-black bg-gray-100 hover:bg-blue-900 hover:text-white rounded-2xl p-6 flex flex-col justify-between shadow-xl
  transform transition-transform duration-300 hover:scale-105
  relative group  // Add 'group' class here
"
                >
                  <div className="mb-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-full inline-flex mb-4">
                      <img src="src/assets/imges/Group 17.svg" alt="" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">
                      Optimizing Product Feature
                    </h3>
                    {/* This paragraph will show on hover */}
                    <p
                      className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
      transition-opacity duration-300     // Smooth transition for opacity
    "
                    >
                      Simply dummy text of the printing and typesetting
                      industry. Lorem ipsum has been the industry's standard
                      dummy text ever since the 1500s, when an unknown printer
                      took.
                    </p>
                  </div>
                  {/* This div containing the button will also show on hover */}
                  <div
                    className="
    self-end mt-4
    opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
    transition-opacity duration-300     // Smooth transition for opacity
  "
                  >
                    <button className="p-3 bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                      <ArrowRight size={24} />
                    </button>
                  </div>
                </div>

                {/* Card: Analyzing Profitability */}
                <div
                  className="
   text-black bg-gray-100 hover:bg-blue-900 hover:text-white rounded-2xl p-6 flex flex-col justify-between shadow-xl
  transform transition-transform duration-300 hover:scale-105
  relative group  // Add 'group' class here
"
                >
                  <div className="mb-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-full inline-flex mb-4">
                      <img src="src/assets/imges/Group 30.svg" alt="" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">
                      Analyzing Profitability
                    </h3>
                    {/* This paragraph will show on hover */}
                    <p
                      className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
      transition-opacity duration-300     // Smooth transition for opacity
    "
                    >
                      Simply dummy text of the printing and typesetting
                      industry. Lorem ipsum has been the industry's standard
                      dummy text ever since the 1500s, when an unknown printer
                      took.
                    </p>
                  </div>
                  {/* This div containing the button will also show on hover */}
                  <div
                    className="
    self-end mt-4
    opacity-0 group-hover:opacity-100   // Hidden by default, visible on group hover
    transition-opacity duration-300     // Smooth transition for opacity
  "
                  >
                    <button className="p-3 bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                      <ArrowRight size={24} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="flex flex-col md:flex-row w-full bg-white  overflow-hidden min-h-[500px]">
          {/* Left Section */}
          <div className="w-full md:w-1/2 bg-blue-950 text-white p-8 sm:p-12 lg:p-16 flex flex-col justify-center">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Strategic Marketing <br className="hidden sm:inline" /> with Clear
              Function
            </h1>
            <p className="text-blue-200 text-base sm:text-lg leading-relaxed mb-8">
              You have a great idea for a whole new business, a new product
              line, or even just a new sku. We help you verify the need for that
              idea and find a path to profitability. Our team of experts in
              growth, design and innovation are at your service. We’ll ensure
              you’ve got the best chance of success for your new idea
            </p>
            <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 self-start">
              Put Us To Work
            </button>
          </div>

          {/* Right Section */}
          <div
            className="w-full md:w-1/2 bg-cover bg-center h-64 md:h-auto"
            style={{
              backgroundImage:
                "url('src/assets/imges/MicrosoftTeams-image (48).png')",
            }}
          ></div>
        </div>
      </section>
      <section>
        <div className="min-h-screen font-sans flex items-center bg-white justify-center p-4 sm:p-6 lg:p-8">
          <div className=" p-6 sm:p-8 md:p-10 lg:p-12 max-w-5xl w-full flex flex-col md:flex-row gap-8 lg:gap-12">
            {/* Left Section: Form */}
            <div className="w-full md:w-1/2 flex flex-col items-center p-4 bg-white shadow-2xl rounded-3xl ">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-800 mb-2 text-center">
                Free Consultation
              </h2>
              <p className="text-gray-600 text-sm sm:text-base mb-8 text-center max-w-xs">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry
              </p>

              <form className="w-full space-y-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <input
                    type="text"
                    placeholder="Full Name"
                    className="w-full sm:flex-1 p-3 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500"
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    className="w-full sm:flex-1 p-3 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500"
                  />
                </div>
                <input
                  type="email"
                  placeholder="Email ID"
                  className="w-full p-3 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500"
                />
                <input
                  type="text"
                  placeholder="Company Name"
                  className="w-full p-3 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500"
                />
                <textarea
                  placeholder="Message"
                  rows="5"
                  className="w-full p-3 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500 resize-y"
                ></textarea>
                <div className="text-center">
                  <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 whitespace-nowrap ">
                    Put Us To Work
                  </button>
                </div>
              </form>
            </div>

            {/* Right Section: Contact Information */}
            <div className="w-full md:w-1/2 p-4 flex flex-col justify-center">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">
                Don't like Filling up forms ?
              </h2>

              <div className="space-y-6">
                {/* Contact Number */}
                <div className="flex items-start">
                  <Phone size={24} className="text-gray-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      Contact number
                    </h3>
                    <p className="text-gray-600">Enquiry : 1800-123-1234</p>
                    <p className="text-gray-600">
                      Appointment : + 1 622 123 3000
                    </p>
                  </div>
                </div>

                {/* Email Address */}
                <div className="flex items-start">
                  <Mail size={24} className="text-gray-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      Email address
                    </h3>
                    <p className="text-gray-600">Sales@brandexponents.com</p>
                    <p className="text-gray-600">Info@brandexponents.com</p>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-start">
                  <MapPin size={24} className="text-gray-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      Location
                    </h3>
                    <p className="text-gray-600">2130 West Street</p>
                    <p className="text-gray-600">Germantown, TN 38138</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="min-h-screen bg-blue-950 font-sans flex flex-col items-center p-4 sm:p-8 lg:p-12">
          {/* Header section with title and subtitle */}
          <div className="text-center mb-10 sm:mb-12 lg:mb-16 max-w-4xl px-4">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
              Past Market Validation Projects
            </h1>
            <p className="text-blue-200 text-base sm:text-lg leading-relaxed">
              Entrepreneurs and Intrapreneurs choose Clear Function when they
              need experts to help them find product market fit.
            </p>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-10 sm:mb-12 lg:mb-16 px-4 max-w-6xl w-full">
            {/* Project Card 1 */}
            <div
              className="relative h-[400px] rounded-xl shadow-lg flex flex-col items-center justify-start text-center transform transition-transform duration-300 hover:scale-105 bg-cover bg-center overflow-hidden"
              style={{
                backgroundImage:
                  "url('src/assets/imges/7f8b9efe3994194ed166d401ccd840ec@2x.png')",
              }}
            >
              <div className="relative p-3 z-10 text-black">
                <h3 className="text-lg sm:text-xl font-semibold mb-2 ">
                  The One where we battled a pandemic and delivered updated
                  systems for a new client
                </h3>
              </div>
            </div>

            {/* Project Card 2 */}
            <div
              className="relative h-[400px] rounded-xl shadow-lg flex flex-col items-center justify-start text-center transform transition-transform duration-300 hover:scale-105 bg-cover bg-center overflow-hidden"
              style={{
                backgroundImage:
                  "url('src/assets/imges/4a08f65389dadc93a9aeba47bcd2d4fc@2x.png')",
              }}
            >
              <div className="relative p-3 z-10 text-black">
                <h3 className="text-lg sm:text-xl font-semibold mb-2">
                  The One where we battled a pandemic and delivered updated
                  systems for a new client
                </h3>
              </div>
            </div>

            {/* Project Card 3 */}
            <div
              className="relative h-[400px] rounded-xl shadow-lg flex flex-col items-center justify-start text-center transform transition-transform duration-300 hover:scale-105 bg-cover bg-center overflow-hidden"
              style={{
                backgroundImage:
                  "url('src/assets/imges/4363768806ca05ff7e78176e1f7053b6@2x.png')",
              }}
            >
              <div className="relative p-3 z-10 text-black">
                <h3 className="text-lg sm:text-xl font-semibold mb-2">
                  The One where we battled a pandemic and delivered updated
                  systems for a new client
                </h3>
              </div>
            </div>
          </div>

          {/* Call to action button */}
          <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 whitespace-nowrap">
            Put Us To Work
          </button>
        </div>
      </section>
      {/* </div> */}
    </>
  );
};

export default Home;
