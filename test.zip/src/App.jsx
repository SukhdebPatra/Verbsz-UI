import { useState } from "react";

import "./App.css";
import Home from "./assets/Pages/Home";
import Test from "./assets/Pages/Test";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <Home />
       <Test/>
    </>
  );
}

export default App;
