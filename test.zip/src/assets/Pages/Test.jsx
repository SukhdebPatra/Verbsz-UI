import React from "react";
import {
  Target,
  TrendingUp,
  SlidersHorizontal,
  DollarSign,
  ArrowRight,
} from "lucide-react";

import "./Home.css";
const Test = () => {
  return (
    <>
      <div className="container mt-2">
        <div className="relative h-80">
          {/* Background block starting from 30% */}
          <div className="absolute top-0  left-[10%] w-[85%] h-full bg-[#FAF9FE] rounded-3xl z-0"></div>

          {/* Content stays in normal flow */}

          <div className="relative z-10 p-6">
            <div className="flex flex-row items-start gap-6 mt-3">
              <div className="col-3 text-3xl text-[#0B325F] right-[10%]">
                <span className="relative left-[10%]">
                  {" "}
                  We Can <br /> Help With
                </span>
              </div>
              <div className="col-6">
                <p>
                  Before sinking tons of money into product development, find
                  out what matters most to your audience. Learn the ins and outs
                  of their preferences and cater your product to meet those
                  needs.
                </p>
              </div>
              <div className="col-3">
                <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-md transition-all duration-300">
                  Put Us To Work
                </button>
              </div>
            </div>

            <div className="flex flex-row justify-between mt-4">
              <div className="col-3 flex flex-col "></div>
              <div
                className="col-2 flex flex-col group relative hover:bg-blue-900 hover:shadow-xl
  transform transition-transform duration-300 hover:scale-105 hover:text-white rounded-2xl p-6"
              >
                {/* Icon */}
                <img
                  src="src/assets/imges/Group 32.svg"
                  alt="Identifying Target Audiences"
                  className="w-12 h-12"
                />

                {/* Title */}
                <p className="text-sm font-bold mb-2">
                  Identifying <br /> Target Audiences
                </p>

                {/* Hover Description */}
                <p
                  className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300 
    "
                >
                  Simply dummy text of the printing and typesetting industry.
                  Lorem ipsum has been the industry's standard dummy text ever
                  since the 1500s, when an unknown printer took.
                </p>

                {/* Hover Button */}
                <div
                  className="
      self-end mt-4
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300
    "
                >
                  <button className="p-3  bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                    <ArrowRight size={24} />
                  </button>
                </div>
              </div>

             <div
                className="col-2 flex flex-col group relative hover:bg-blue-900 hover:shadow-xl
  transform transition-transform duration-300 hover:scale-105 hover:text-white rounded-2xl p-6"
              >
                {/* Icon */}
                <img
                  src="src/assets/imges/Group 15.svg"
                  alt="Identifying Target Audiences"
                  className="w-12 h-12"
                />

                {/* Title */}
                <p className="text-sm font-bold mb-2">
                  Generating <br /> Conversions
                </p>

                {/* Hover Description */}
                <p
                  className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300 
    "
                >
                  Simply dummy text of the printing and typesetting industry.
                  Lorem ipsum has been the industry's standard dummy text ever
                  since the 1500s, when an unknown printer took.
                </p>

                {/* Hover Button */}
                <div
                  className="
      self-end mt-4
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300
    "
                >
                  <button className="p-3  bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                    <ArrowRight size={24} />
                  </button>
                </div>
              </div>
              <div
                className="col-2 flex flex-col group relative hover:bg-blue-900 hover:shadow-xl
  transform transition-transform duration-300 hover:scale-105 hover:text-white rounded-2xl p-6"
              >
                {/* Icon */}
                <img
                  src="src/assets/imges/Group 15.svg"
                  alt="Identifying Target Audiences"
                  className="w-12 h-12"
                />

                {/* Title */}
                <p className="text-sm font-bold mb-2">
                  Generating <br /> Conversions
                </p>

                {/* Hover Description */}
                <p
                  className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300 
    "
                >
                  Simply dummy text of the printing and typesetting industry.
                  Lorem ipsum has been the industry's standard dummy text ever
                  since the 1500s, when an unknown printer took.
                </p>

                {/* Hover Button */}
                <div
                  className="
      self-end mt-4
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300
    "
                >
                  <button className="p-3  bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                    <ArrowRight size={24} />
                  </button>
                </div>
              </div>
             <div
                className="col-2 flex flex-col group relative hover:bg-blue-900 hover:shadow-xl
  transform transition-transform duration-300 hover:scale-105 hover:text-white rounded-2xl p-6"
              >
                {/* Icon */}
                <img
                  src="src/assets/imges/Group 15.svg"
                  alt="Identifying Target Audiences"
                  className="w-12 h-12"
                />

                {/* Title */}
                <p className="text-sm font-bold mb-2">
                  Generating <br /> Conversions
                </p>

                {/* Hover Description */}
                <p
                  className="
      text-gray-300 text-sm leading-relaxed
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300 
    "
                >
                  Simply dummy text of the printing and typesetting industry.
                  Lorem ipsum has been the industry's standard dummy text ever
                  since the 1500s, when an unknown printer took.
                </p>

                {/* Hover Button */}
                <div
                  className="
      self-end mt-4
      opacity-0 group-hover:opacity-100
      transition-opacity duration-300
    "
                >
                  <button className="p-3  bg-white text-blue-900 rounded-full shadow-lg flex items-center justify-center">
                    <ArrowRight size={24} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Test;
